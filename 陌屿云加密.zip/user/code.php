<?php
/*
Auat：陌屿
QQ：123456
Grup：123456
Name：陌屿云加密系统
*/
session_start();
define('ROOT_PATH', dirname(__FILE__));
require '../includes/code.class.php';
$_mulin = new ValidateCode();
$_mulin->doimg();
$_SESSION['mulin_code'] = $_mulin->getCode();
?>