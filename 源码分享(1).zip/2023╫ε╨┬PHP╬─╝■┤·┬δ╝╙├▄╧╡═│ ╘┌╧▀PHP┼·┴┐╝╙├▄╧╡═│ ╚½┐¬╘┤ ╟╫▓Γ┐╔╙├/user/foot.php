        </div>
       <!-- END Page Content -->
        </div>
        <!-- END Main Container -->
    </div>
    <!-- END Page Container -->
</div>
<!-- END Page Wrapper -->

<!-- jQuery, Bootstrap, jQuery plugins and Custom JS code -->
<script src="../assets/static/user_style/js/vendor/jquery-2.2.0.min.js"></script>
<script src="../assets/static/user_style/js/vendor/bootstrap.min.js"></script>
<script src="../assets/static/user_style/js/plugins.js"></script>
<script src="../assets/static/user_style/js/app.js"></script>
<script src="../assets/static/sweetalert/sweetalert.min.js"></script>
<?php
?>
<script src="../assets/static/layer/layer.js"></script>
<script src="../assets/static/user_style/js/jquery.cookie.min.js"></script>

<!-- Load and execute javascript code used only in this page -->
<script src="../assets/static/user_style/js/pages/uiWidgets.js"></script>
<script>$(function () {
    UiWidgets.init();
});
</script>

</body>
</html>

</body>
</html>